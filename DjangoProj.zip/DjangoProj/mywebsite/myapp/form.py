from django import forms
from myapp.models import Category, Post, User

class UserForm(forms.ModelForm):
    class Meta:
        model=User
        fields='__all__'

class CategoryForm(forms.ModelForm):
    class Meta:
        model=Category
        fields='__all__'

class PostForm(forms.ModelForm):
    class Meta:
        model=Post
        fields='__all__'