
from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.HomePage),
    path('adduser',views.AddUserPage),
    path('User',views.AddUser),
    path('userlist',views.UserList),
    path('addcategorypage',views.AddCategoryPage),
    path('addcategory',views.AddCategory),
    path('categorylist',views.CategoryList),
    path('addpostpage',views.AddPostPage),
    path('addpost',views.AddPost),
    path('postlist',views.PostList),
    path('login',views.login),
    path('logoutpage',views.Logout),

]
