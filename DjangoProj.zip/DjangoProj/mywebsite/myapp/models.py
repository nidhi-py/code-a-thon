from django.db import models


# Create your models here.

class User(models.Model):
    name=models.CharField(max_length=30)
    contact=models.CharField(max_length=15)
    email=models.CharField(primary_key=True,max_length=15)
    password=models.CharField(max_length=30)

class Category(models.Model):
    cname =models.CharField(max_length=30, primary_key=True)

class Post(models.Model):
    topic=models.CharField(max_length=20)
    author=models.CharField(max_length=30)
    body=models.TextField(max_length=30)
    cname=models.ForeignKey(Category,on_delete=models.CASCADE)
