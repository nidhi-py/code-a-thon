from django.shortcuts import render, redirect
from django.http import HttpResponse
from myapp.models import Category,Post, User
from myapp.form import CategoryForm, PostForm, UserForm

# Create your views here.

def HomePage(request):
    c=Category.objects.all()
    cat=request.GET.get('cat')
    if cat is not None:
        pl=Post.objects.filter(cname=cat)
        return render(request,'index.html',{'c':c,'pl':pl})
    else:
        pl=Post.objects.all()
        return render(request,'index.html',{'c':c,'pl':pl})

def AddUserPage(request):
    u= UserForm  #it will consider the bracket anyhow
    return render(request,'adduser.html',{'form3':u})

def AddUser(request):
    u= UserForm(request.POST)
    if u.is_valid:
        u.save()
        return render(request,'index.html')
    return HttpResponse('<h1> Fail </h1>')

def UserList(request):
    ul=User.objects.all()
    return render(request,'userlist.html',{'url':ul})

def AddCategoryPage(request):
    c= CategoryForm
    return render(request,'addcategory.html',{'form':c})

def AddCategory(request):
    c= CategoryForm(request.POST)
    if a.is_valid:
        a.save()
        return render(request,'index.html')
    return HttpResponse('<h1> FAIL </h1>')

def CategoryList(request):
    c= Category.objects.all()
    return render(request, 'categorylist.html',{'form1':c})

def AddPostPage(request):
    p= PostForm
    return render(request,'addpost.html',{'ap':p})

def AddPost(request):
    p= PostForm(request.POST)
    if a.is_valid:
        a.save()
        return render(request,'index.html')
    return HttpResponse('<h1> FAIL </h1>')

def PostList(request):
    p= Post.objects.all()
    return render(request, 'postlist.html',{'form2':p})

def loginpage(request):
    return render(request,'login.html')

def login(request):
    em=request.POST.get('email')
    passwd=request.POST.get('password')
    #print(email,'  ',password)
    if em=="nidhi@123" and passwd=="21298":
        request.session['admin']=em
        return redirect('/HomePage')
    else:
        try:
            ul=User.objects.get(email=em)
            if em==ul.email and passwd==ul.password:
                request.session['username']=em
                return redirect("/HomePage")
            else:
                return HttpResponse("Template not found")
        except:
            return render(request,'login.html')#{'msg':""}

def Logout(request):
    ls=list(request.session.keys())
    for i in ls:
        del request.session[i]
    return redirect('/HomePage')